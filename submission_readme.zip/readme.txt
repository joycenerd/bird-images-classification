sample_submission.zip
	Should contain the answer.txt file. Please note that your predictions of files should have the same order as the sample answer.txt.

sample_pseudo_code.py:
	The sample pseudo code to produce the "answer.txt" file from your predicted model